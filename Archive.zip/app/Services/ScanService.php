<?php

namespace App\Services;

class ScanService {

    function createScan()
    {

    }

}
